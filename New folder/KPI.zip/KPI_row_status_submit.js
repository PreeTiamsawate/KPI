const submitBtnTest = document.querySelector('#submitPage');

submitBtnTest.addEventListener('click', function(e) {
    e.preventDefault()
    const greenRows = document.querySelectorAll("tr[row-status='newly-filled']")
    const submitBtn = document.querySelector('#submitPage');
    const paginationWrapper = document.querySelector("#pagination-wrapper")
    const paginationBtns = document.querySelectorAll("#pagination-wrapper > .btn")
    for (const greenRow of greenRows) {
        greenRow.style.backgroundColor = "#FFFFFF";
        greenRow.setAttribute("row-status", "fully-filled")

    }
    submitBtn.style.backgroundColor = "#330066";
    paginationWrapper.style.backgroundColor = "transparent";
    paginationWrapper.style.cursor = "pointer"
    for (const paginationBtn of paginationBtns) {
        paginationBtn.disabled = false
    }
})